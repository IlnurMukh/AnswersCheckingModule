import os

# Папка с моделями анализатора
LANGUAGE_DIRECTORY = os.path.join(os.path.dirname(__file__), "languages")
